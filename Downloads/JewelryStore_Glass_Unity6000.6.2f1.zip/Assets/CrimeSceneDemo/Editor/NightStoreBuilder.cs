#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using static DemoGeometry;
using L = NightStoreLayout;

// Generates the expanded night store from NightStoreLayout: root "NightStore" with
// Architecture (floor, walls, partitions, skirting, the walnut architraves round the office
// opening, the ceiling with its shadow gap and its fittings, CCTV domes and smoke
// detectors), Facade (window bays, forced entrance, cladding, alarm bell box), Exterior
// (pavement, kerb, wet street, buildings and the apartment block across the street,
// bollards, streetlights, police car, equipment table and easel, street furniture and
// figures from NightStreet, play-area walls), Showroom and Office (StoreKit fixtures, the
// wall devices among them, and the corner camera, square to its partition with only its
// housing turned by NightStoreLayout.CameraAim; then NightInterior's props and wall
// graphics), Dressing (NightStoreDressing, then NightDecals) and Anchors, the
// hidden UV trace examples (UVTraceBuilder), then the tool station with the night
// ToolLayout and the soundscape (NightAudioBuilder). CreatePlayer puts the rig at the
// spawn beside the car with the layout's movement regions and its footsteps. Every
// police-specific choice (car, light bar, tape text, sounds, figure) comes from
// PoliceLook; the credits of whatever the build placed go to DemoCredits.txt.
//
// Surfaces are KitMesh parts built in world coordinates, so the metric UVs (and the
// ReferenceTextures tiling) run continuously across walls and slabs, with lightmap
// UVs; collisions are plain BoxColliders on "Colliders" children. Everything that
// never moves is marked static for the bake (StoreKit.MarkStatic).
public static class NightStoreBuilder
{
    public const string Folder = "Assets/CrimeSceneDemo/NightStoreGenerated";

    // ---------------------------------------------------------------- menu
    // The validator's generation steps without the checks and captures: a quick build
    // previews the lights as realtime shadowless lights; Build And Bake (minutes) or
    // Bake Lighting Only gives the shipped look. Both save Scenes/JewelryStoreNight.
    private const string Menu = "Crime Scene Demo/Night Store/";

    [MenuItem(Menu + "Build (quick)", false, 0)]
    public static void BuildQuickMenu() { BuildScene(false); }

    [MenuItem(Menu + "Build And Bake", false, 1)]
    public static void BuildAndBakeMenu() { BuildScene(true); }

    [MenuItem(Menu + "Bake Lighting Only", false, 2)]
    public static void BakeMenu()
    {
        if (EditorApplication.isPlaying) return;
        GameObject root = GameObject.Find(L.Root);
        if (root == null || root.transform.Find(NightLighting.GroupName) == null)
        {
            EditorUtility.DisplayDialog("Night store required", "Open or build the night store (with its lighting) first.", "OK");
            return;
        }
        // The baked intensities assume linear colour space with linear light intensities.
        NightLighting.UseLinearColorSpace();
        // A quick build's realtime preview lights go back to baked before the bake.
        NightLighting.UseBaked(root.transform);
        if (string.IsNullOrEmpty(SceneManager.GetActiveScene().path)) DemoValidation.SaveScene(L.SceneName, false);
        else DemoValidation.SaveScene();
        NightLighting.Bake(out string report);
        Debug.Log(report);
        DemoValidation.SaveScene();
    }

    // Edit mode: the same switch the presenter panel makes in Play mode (DemoLighting),
    // a shadowless realtime sun and a grey ambient. Switch back to night before saving.
    [MenuItem(Menu + "Toggle Diagnostic Daylight", false, 20)]
    public static void ToggleDaylightMenu()
    {
        DemoLighting lighting = UnityEngine.Object.FindFirstObjectByType<DemoLighting>();
        GameObject root = GameObject.Find(L.Root);
        if (lighting == null || lighting.DiagnosticSun == null || root == null)
        {
            EditorUtility.DisplayDialog("Night store required", "Open or build the night store (with its lighting) first.", "OK");
            return;
        }
        if (EditorApplication.isPlaying) { lighting.ToggleNight(); return; }
        bool day = !lighting.DiagnosticSun.enabled;
        lighting.DiagnosticSun.enabled = day;
        RenderSettings.ambientLight = day ? lighting.DiagnosticAmbient : NightLighting.NightAmbientFor(root.transform);
        EditorUtility.SetDirty(lighting.DiagnosticSun);
        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Debug.Log(day ? "Diagnostic daylight on (edit mode). Toggle it off again before saving the night scene." : "Night restored.");
    }

    [MenuItem(Menu + "Store Kit Gallery", false, 40)]
    public static void GalleryMenu() { StoreKit.GalleryMenu(); }

    // askToSave is false for DemoBuild.BuildLatest, which runs in batch mode with no one to ask.
    // Returns true when the scene ships baked lighting. A failed or skipped bake falls back to
    // the realtime preview, so a build never ships baked-only lights without lightmaps (black).
    public static bool BuildScene(bool bake, bool askToSave = true)
    {
        if (EditorApplication.isPlaying || (askToSave && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())) return false;
        NightLighting.UseLinearColorSpace();
        ThirdPartyModelImport.GenerateLightmapUVs();
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        Camera camera = DemoValidation.CreatePreviewCamera(150);
        GameObject root = Build(true);
        NightLighting.Apply(root.transform, camera);
        DemoValidation.SaveScene(L.SceneName, false);
        bool baked = false;
        if (bake)
        {
            // The same success test as NightStoreValidation's "Night lighting bakes".
            baked = NightLighting.Bake(out string report) && LightmapSettings.lightmaps.Length > 0;
            Debug.Log(report);
            if (!baked) { Debug.LogWarning("JEWELRY_BUILD_LIGHTING bake failed; using the realtime preview."); Lightmapping.Clear(); }
        }
        if (!baked) NightLighting.UseRealtimeFallback(root.transform);
        // The rig is created after the bake so it never enters it (as in the validator).
        CreatePlayer(camera);
        NightLighting.ConfigureCamera(camera);
        DemoValidation.SaveScene();
        Debug.Log("JEWELRY_BUILD_LIGHTING " + (baked ? "baked" : "preview"));
        return baked;
    }

    public static GameObject Build(bool useImportedAssets)
    {
        if (GameObject.Find(L.Root) != null) throw new InvalidOperationException("Night store already exists. Build into a fresh scene.");
        EnsureFolder("Assets/CrimeSceneDemo");
        EnsureFolder(Folder);
        StoreKit.Palette();
        // The credits list only what this build places.
        DemoAssetLibrary.ResetCredits();
        GameObject root = new GameObject(L.Root);
        Dictionary<string, Transform> zone = new Dictionary<string, Transform>();
        foreach (string name in L.Zones) zone[name] = Group(name, root.transform);

        Architecture(zone["Architecture"]);
        Facade(zone["Facade"]);
        Exterior(zone["Exterior"], useImportedAssets);
        foreach (L.Fixture f in L.Fixtures) Place(f, zone[f.Zone]);
        InteriorSigns(zone["Showroom"], zone["Office"]);
        // Interior props and wall graphics, before the static flags (they bake with their zones).
        NightInterior.Apply(root.transform, useImportedAssets);
        NightStoreDressing.Apply(zone["Dressing"], zone["Showroom"], Folder);
        MergeCaseGlass(zone["Showroom"]);
        foreach (string name in L.AnchorNames)
        {
            Transform anchor = Group(name, zone["Anchors"]);
            anchor.localPosition = L.Anchor(name);
            if (name == "PlayerSpawn") anchor.localRotation = Quaternion.Euler(0, L.PlayerYaw, 0);
        }

        // Nothing in the night scene moves at runtime (forced leaves, open safe doors,
        // the pulled drawer and the closed side-room doors stay put), so door leaves and
        // drawers bake with everything else; small parts still go to the probes.
        StoreKit.MarkStatic(zone["Architecture"].gameObject, true, true);
        // The ceiling slab is also the roof: as an occluder it would hide the whole
        // interior from the top-down map and overview cameras once occlusion is baked.
        foreach (MeshRenderer r in root.transform.Find(L.CeilingPath).GetComponentsInChildren<MeshRenderer>(true))
            GameObjectUtility.SetStaticEditorFlags(r.gameObject, GameObjectUtility.GetStaticEditorFlags(r.gameObject) & ~StaticEditorFlags.OccluderStatic);
        StoreKit.MarkStatic(zone["Facade"].gameObject, true);
        StoreKit.MarkStatic(zone["Exterior"].gameObject, false);
        StoreKit.MarkStatic(zone["Exterior"].Find("Buildings").gameObject, false, true);
        StoreKit.MarkStatic(zone["Showroom"].gameObject, true);
        StoreKit.MarkStatic(zone["Office"].gameObject, true);
        StoreKit.MarkStatic(zone["Dressing"].gameObject, true);
        foreach (string name in NightStoreDressing.Unbatched)
        {
            Transform fan = zone["Dressing"].Find(name);
            if (fan != null) GameObjectUtility.SetStaticEditorFlags(fan.gameObject, 0);
        }
        NightStoreDressing.CombineLoose(zone["Dressing"], Folder);
        // Decals and the hidden presenter sets set their own static flags, after MarkStatic
        // (never occluders or reflection-probe static).
        NightDecals.Apply(root.transform, Folder, useImportedAssets);
        // NightLighting.LightmapScales sets every zone's lightmap scale after Build (Apply
        // always follows Build); the KitMeshes' chart margins match it.

        // Placeholder UV traces, hidden; the presenter panel shows them through DemoLighting.
        GameObject examples = UVTraceBuilder.NightExamples(root.transform);
        DemoToolsBuilder.Create(useImportedAssets, L.Tools);
        // Staged clips, the soundscape and the music, beside the tool station's ambience.
        NightAudioBuilder.Apply(root.transform);
        DemoLighting lighting = UnityEngine.Object.FindFirstObjectByType<DemoLighting>();
        if (lighting != null) lighting.UVExamples = examples;
        DemoAssetLibrary.WriteCredits(DemoUi.DefaultCredits + " Night store: Poly Haven, ambientCG and John Bartmann (CC0).");
        AssetDatabase.SaveAssets();
        return root;
    }

    // A case's four or five panes share KitGlass, but as separate renderers each is its
    // own sorted, unbatched transparent draw per eye (about 60 for the fourteen cases).
    // One glass mesh per case keeps them to one. Any child of a pane (the cracked top's
    // CrackPlane) moves to the case first. Cases of the same kind and glass state share
    // the mesh asset, since the panes sit identically in fixture space.
    private static void MergeCaseGlass(Transform showroom)
    {
        foreach (L.Fixture f in L.Fixtures)
        {
            if (f.Kit != "display_case" && f.Kit != "wall_case") continue;
            Transform fixture = showroom.Find(f.Name);
            if (fixture == null) continue;
            List<CombineInstance> panes = new List<CombineInstance>();
            List<GameObject> merged = new List<GameObject>();
            Material glass = null;
            foreach (Transform pane in fixture)
            {
                MeshFilter filter = pane.GetComponent<MeshFilter>();
                MeshRenderer renderer = pane.GetComponent<MeshRenderer>();
                if (!pane.name.StartsWith("Glass_") || filter == null || renderer == null || filter.sharedMesh == null) continue;
                glass = renderer.sharedMaterial;
                panes.Add(new CombineInstance { mesh = filter.sharedMesh, transform = fixture.worldToLocalMatrix * pane.localToWorldMatrix });
                merged.Add(pane.gameObject);
            }
            if (panes.Count < 2) continue;
            foreach (GameObject pane in merged)
                for (int i = pane.transform.childCount - 1; i >= 0; i--) pane.transform.GetChild(i).SetParent(fixture, true);
            Mesh mesh = new Mesh { name = "CaseGlass" };
            mesh.CombineMeshes(panes.ToArray(), true, true);
            SaveMesh(ref mesh, Folder + "/night_case_glass_" + f.Kit + "_" + NightStoreDressing.CaseGlass(f.Name) + ".asset");
            GameObject g = new GameObject("Glass");
            g.transform.SetParent(fixture, false);
            g.AddComponent<MeshFilter>().sharedMesh = mesh;
            MeshRenderer r = g.AddComponent<MeshRenderer>();
            r.sharedMaterial = glass;
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = false;
            foreach (GameObject pane in merged) UnityEngine.Object.DestroyImmediate(pane);
        }
    }

    // The rig at the spawn, with the soundscape's footsteps on it.
    public static ShopWalkController CreatePlayer(Camera camera)
    {
        ShopWalkController walker = DemoToolsBuilder.CreatePlayer(camera, L.PlayerSpawn, L.PlayerYaw, L.Regions());
        NightAudioBuilder.AttachPlayer(walker);
        return walker;
    }

    // ---------------------------------------------------------------- architecture

    // Walnut architraves round the office opening on both faces of the partition: 45 mm
    // wide, 18 mm proud (3 mm prouder than the skirting, which butts into their legs). The
    // shadow gap is a dark 15 mm strip under the ceiling, 3 mm off the showroom and office walls.
    public const float ArchitraveWidth = 0.045f, ArchitraveProud = 0.018f, ShadowGapHeight = 0.015f, ShadowGapOffset = 0.003f;
    public const string ArchitravesName = "Architraves", ShadowGapName = "ShadowGap";

    private static void Architecture(Transform parent)
    {
        GameObject solid = Group("Colliders", parent).gameObject;
        KitMesh floor = new KitMesh(), walls = new KitMesh(), trim = new KitMesh(), ceiling = new KitMesh();
        float w = L.Wall, top = L.CeilingY, half = L.Partition * 0.5f, rz = L.RearZ, oh = L.OfficeHalf;
        Slab(floor, solid, StoreKit.Floor, V(L.MinX - w, -L.Slab, L.MinZ), V(L.MaxX + w, 0, L.MaxZ + w), false);

        // Outer walls stand outside the interior and rise to the parapet.
        Slab(walls, solid, StoreKit.Plaster, V(L.MinX - w, 0, L.MinZ), V(L.MinX, L.ParapetY, L.MaxZ + w));
        Slab(walls, solid, StoreKit.Plaster, V(L.MaxX, 0, L.MinZ), V(L.MaxX + w, L.ParapetY, L.MaxZ + w));
        Slab(walls, solid, StoreKit.Plaster, V(L.MinX - w, 0, L.MaxZ), V(L.MaxX + w, L.ParapetY, L.MaxZ + w));

        // Rear partitions with the side-room doors, the office front with its flush
        // opening, and the office side walls, all full height.
        float officeDoor = L.Find("OfficeDoor").Position.x, serviceDoor = L.Find("ServiceDoor").Position.x;
        Opening(walls, solid, L.MinX, -oh - half, rz, officeDoor, 0.45f, 2.1f);
        Opening(walls, solid, oh + half, L.MaxX, rz, serviceDoor, 0.45f, 2.1f);
        Opening(walls, solid, -oh - half, oh + half, rz, 0, L.OfficeOpeningHalf, L.OfficeOpeningHeight);
        for (int s = -1; s <= 1; s += 2)
            Slab(walls, solid, StoreKit.Plaster, V(s * oh - half, 0, rz), V(s * oh + half, top, L.MaxZ));

        // Walnut skirting along the showroom and office walls (gaps at the doors and the
        // opening). The segments butt at every corner, the architrave legs and the door
        // casings instead of overlapping there, so no two faces overlap in one plane: the
        // partition's runs stop at the side skirting's face and at the legs' outer faces
        // (x +-(OfficeOpeningHalf + ArchitraveWidth)), and the office back run and the office
        // face of the partition (+24 triangles) stop at the office side skirting.
        const float sk = 0.1f, st = 0.015f;
        float legs = L.OfficeOpeningHalf + ArchitraveWidth;
        Slab(trim, null, StoreKit.Walnut, V(L.MinX, 0, L.MinZ), V(L.MinX + st, sk, rz - half));
        Slab(trim, null, StoreKit.Walnut, V(L.MaxX - st, 0, L.MinZ), V(L.MaxX, sk, rz - half));
        float[] front = { L.MinX + st, officeDoor - 0.52f, officeDoor + 0.52f, -legs, legs, serviceDoor - 0.52f, serviceDoor + 0.52f, L.MaxX - st };
        for (int i = 0; i + 1 < front.Length; i += 2)
            Slab(trim, null, StoreKit.Walnut, V(front[i], 0, rz - half - st), V(front[i + 1], sk, rz - half));
        for (int s = -1; s <= 1; s += 2)
            Slab(trim, null, StoreKit.Walnut, V(s * (oh - half) - (s > 0 ? st : 0), 0, rz + half), V(s * (oh - half) + (s < 0 ? st : 0), sk, L.MaxZ));
        Slab(trim, null, StoreKit.Walnut, V(-oh + half + st, 0, L.MaxZ - st), V(oh - half - st, sk, L.MaxZ));
        // The office face of the partition, from the architrave legs to the office side skirting.
        for (int s = -1; s <= 1; s += 2)
            Slab(trim, null, StoreKit.Walnut, V(Mathf.Min(s * legs, s * (oh - half - st)), 0, rz + half), V(Mathf.Max(s * legs, s * (oh - half - st)), sk, rz + half + st));

        floor.Emit("Floor", parent, Vector3.zero, Quaternion.identity, Folder, "night_floor");
        walls.Emit("Walls", parent, Vector3.zero, Quaternion.identity, Folder, "night_walls");
        trim.Emit("Skirting", parent, Vector3.zero, Quaternion.identity, Folder, "night_skirting");

        // Architraves round the office opening on both faces (bevelled bars, lightmapped at the
        // shell's density): two legs from the floor and the head between them, as HingedDoor's
        // casings, their backs on the partition. The head tops at 2.445, under the wall clock;
        // the legs end at x +-0.845, short of the extinguisher and the fire plan.
        KitMesh architraves = new KitMesh();
        float legHeight = L.OfficeOpeningHeight + ArchitraveWidth;
        foreach (float n in new[] { -1f, 1f })
        {
            float z = (n < 0 ? NightInterior.ShowroomFace : NightInterior.OfficeFace) + n * ArchitraveProud * 0.5f;
            for (int s = -1; s <= 1; s += 2)
                architraves.Bar(StoreKit.Walnut, V(s * (L.OfficeOpeningHalf + ArchitraveWidth * 0.5f), legHeight * 0.5f, z), V(ArchitraveWidth, legHeight, ArchitraveProud), 0.003f);
            architraves.Bar(StoreKit.Walnut, V(0, L.OfficeOpeningHeight + ArchitraveWidth * 0.5f, z), V(2 * L.OfficeOpeningHalf, ArchitraveWidth, ArchitraveProud), 0.003f);
        }
        architraves.Emit(ArchitravesName, parent, Vector3.zero, Quaternion.identity, Folder, "night_architraves");

        // Ceiling slab (its top is the roof) with the fittings, all off. The overview
        // capture and the presenter map hide this whole group.
        Transform ceilingGroup = Group("Ceiling", parent);
        GameObject ceilingSolid = Group("Colliders", ceilingGroup).gameObject;
        Slab(ceiling, ceilingSolid, StoreKit.CeilingPaint, V(L.MinX, top, L.MinZ), V(L.MaxX, top + L.Slab, L.MaxZ));
        ceiling.Emit("CeilingSlab", ceilingGroup, Vector3.zero, Quaternion.identity, Folder, "night_ceiling");

        // Shadow gap: a dark strip ShadowGapOffset off each showroom and office wall under the
        // ceiling, facing the room (seven faces, 14 triangles). Probe-lit (a 15 mm strip would
        // waste a lightmap chart) and shadowless. None runs on the facade, whose window heads
        // reach the ceiling: the side strips start at the end bays' outer mullions, whose backs
        // (z 0.06) are the only frame at the wall line (the heads stop 4 cm short of it).
        KitMesh gap = new KitMesh { Lightmapped = false };
        float g0 = top - ShadowGapHeight, e = ShadowGapOffset, sz = rz - half - e, oz = rz + half + e, ox = oh - half - e, head = 0.06f;
        for (int s = -1; s <= 1; s += 2)
        {
            float x = s < 0 ? L.MinX + e : L.MaxX - e;
            gap.Face(StoreKit.DeviceBlack, V(-s, 0, 0), V(x, g0, head), V(x, g0, sz), V(x, top, sz), V(x, top, head));
            gap.Face(StoreKit.DeviceBlack, V(-s, 0, 0), V(s * ox, g0, oz), V(s * ox, g0, L.MaxZ - e), V(s * ox, top, L.MaxZ - e), V(s * ox, top, oz));
        }
        gap.Face(StoreKit.DeviceBlack, Vector3.back, V(L.MinX + e, g0, sz), V(L.MaxX - e, g0, sz), V(L.MaxX - e, top, sz), V(L.MinX + e, top, sz));
        gap.Face(StoreKit.DeviceBlack, Vector3.back, V(-ox, g0, L.MaxZ - e), V(ox, g0, L.MaxZ - e), V(ox, top, L.MaxZ - e), V(-ox, top, L.MaxZ - e));
        gap.Face(StoreKit.DeviceBlack, Vector3.forward, V(-ox, g0, oz), V(ox, g0, oz), V(ox, top, oz), V(-ox, top, oz));
        MeshRenderer gapRenderer = gap.Emit(ShadowGapName, ceilingGroup, Vector3.zero, Quaternion.identity, Folder, "night_shadow_gap").GetComponent<MeshRenderer>();
        if (gapRenderer != null) gapRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;

        Vector3[] downlights = L.Downlights();
        for (int i = 0; i < downlights.Length; i++)
            StoreKit.Instantiate("downlight", ceilingGroup, downlights[i], 0).name = "Downlight_" + i;
        for (int i = 0; i < L.Tracks.Length; i++)
            StoreKit.Instantiate("track_light", ceilingGroup, L.Tracks[i], L.Tracks[i].w).name = "TrackLight_" + i;
        // CCTV domes and smoke detectors, flush under the slab (small props: probe-lit, out of GI).
        for (int i = 0; i < L.Domes.Length; i++)
            StoreKit.Instantiate("cctv_dome", ceilingGroup, L.Domes[i], 0).name = "CctvDome_" + i;
        for (int i = 0; i < L.SmokeDetectors.Length; i++)
            StoreKit.Instantiate("smoke_detector", ceilingGroup, L.SmokeDetectors[i], 0).name = "SmokeDetector_" + i;
    }

    // A full-height partition along x at z with one opening (gapCentre +- gapHalf, up to gapTop).
    private static void Opening(KitMesh k, GameObject solid, float x0, float x1, float z, float gapCentre, float gapHalf, float gapTop)
    {
        float half = L.Partition * 0.5f, top = L.CeilingY;
        Slab(k, solid, StoreKit.Plaster, V(x0, 0, z - half), V(gapCentre - gapHalf, top, z + half));
        Slab(k, solid, StoreKit.Plaster, V(gapCentre + gapHalf, 0, z - half), V(x1, top, z + half));
        Slab(k, solid, StoreKit.Plaster, V(gapCentre - gapHalf, gapTop, z - half), V(gapCentre + gapHalf, top, z + half));
    }

    // Axis-aligned box from min to max into k, with a matching collider on solid (when given).
    private static void Slab(KitMesh k, GameObject solid, Material m, Vector3 min, Vector3 max, bool bottom = true)
    {
        Vector3 centre = (min + max) * 0.5f, size = max - min;
        k.Box(m, centre, size, bottom);
        if (solid == null) return;
        BoxCollider c = solid.AddComponent<BoxCollider>();
        c.center = centre;
        c.size = size;
    }

    // ---------------------------------------------------------------- facade

    private static void Facade(Transform parent)
    {
        for (int bay = 0; bay < L.Bays; bay++)
        {
            if (L.IsEntranceBay(bay)) continue;
            GameObject module = StoreKit.WindowModule(parent, L.BayState(bay));
            module.name = "Bay_" + bay;
            module.transform.localPosition = V(L.BayCentre(bay), 0, 0);
        }
        float sx = L.DoorHalf + L.SidelightWidth * 0.5f;
        GameObject left = StoreKit.WindowModule(parent, L.LeftSidelight, L.SidelightWidth);
        left.name = "Sidelight_Left";
        left.transform.localPosition = V(-sx, 0, 0);
        GameObject right = StoreKit.WindowModule(parent, L.RightSidelight, L.SidelightWidth);
        right.name = "Sidelight_Right";
        right.transform.localPosition = V(sx, 0, 0);
        GameObject doors = StoreKit.StorefrontDoors(parent, L.DoorLeftOpen, L.DoorRightOpen, true, true);
        doors.name = "EntranceDoors";

        // Transom panel over the doors, then the stone-clad end piers, fascia and coping.
        GameObject solid = Group("Colliders", parent).gameObject;
        KitMesh frame = new KitMesh { LightmapScale = NightLighting.FixtureScale }, stone = new KitMesh { LightmapScale = NightLighting.FixtureScale };
        Slab(frame, solid, StoreKit.FrameMetal, V(-L.DoorHalf, L.DoorHeight, -0.06f), V(L.DoorHalf, L.CeilingY, 0.06f));
        frame.Emit("Transom", parent, Vector3.zero, Quaternion.identity, Folder, "night_transom");
        const float front = -0.2f, back = 0.25f;
        float pier = L.Pier;
        for (int s = -1; s <= 1; s += 2)
            Slab(stone, solid, StoreKit.Cladding, V(s < 0 ? L.MinX - pier : L.MaxX, 0, front), V(s < 0 ? L.MinX : L.MaxX + pier, L.ParapetY, back));
        Slab(stone, solid, StoreKit.Cladding, V(L.MinX, L.CeilingY, front), V(L.MaxX, L.ParapetY, back));
        Slab(stone, null, StoreKit.Concrete, V(L.MinX - pier - 0.05f, L.ParapetY, front - 0.05f), V(L.MaxX + pier + 0.05f, L.ParapetY + 0.06f, back + 0.05f));
        stone.Emit("Cladding", parent, Vector3.zero, Quaternion.identity, Folder, "night_cladding");

        // Alarm bell box on the fascia band (a plain project-made housing, no brand): its back
        // on the cladding, a strobe lens across the top of its face. Whether the bell still
        // rings is a presenter switch (NightAudioBuilder), off at arrival.
        KitMesh bell = new KitMesh { LightmapScale = NightLighting.FixtureScale };
        bell.Box(StoreKit.Lacquer, Vector3.zero, V(0.28f, 0.36f, 0.09f));
        bell.Box(StoreKit.DeviceGrey, V(0, 0.13f, -0.055f), V(0.10f, 0.05f, 0.02f));
        bell.Emit("BellBox", parent, L.BellBox, Quaternion.identity, Folder, "night_bell_box");

        // Shop name on the fascia band above the entrance, 5 mm proud of the cladding.
        Sign(FasciaSign, "ShopFascia", parent, V(0, (L.CeilingY + L.ParapetY) * 0.5f, front - 0.005f), new Vector2(2.2f, 0.55f));
        // Small Closed card inside the left door's glass, above the hole, read from the
        // street; its plain back faces the shop.
        Transform leaf = doors.transform.Find("DoorLeft");
        if (leaf != null && Sign(ClosedSign, "Closed", leaf, V(0.4575f, 2.02f, -0.019f), new Vector2(0.4f, 0.2f)) != null)
        {
            GameObject card = Primitive(ClosedSign + "Back", PrimitiveType.Quad, leaf, V(0.4575f, 2.02f, -0.018f), new Vector3(0.4f, 0.2f, 1), StoreKit.Lacquer);
            card.transform.localRotation = Quaternion.Euler(0, 180, 0);
            card.GetComponent<MeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        }
    }

    // ---------------------------------------------------------------- staged signs and sounds

    // Prototype/ThirdParty/NightGraphics (fictional Aurel & Finch family). The decals,
    // tape and marker atlas in that pack are deliberately not placed here.
    public const string GraphicsPack = "NightGraphics";
    public const string FasciaSign = "FasciaSign", ClosedSign = "ClosedSign", StaffSign = "StaffOnlySign", CollectionSign = "CollectionSign";
    public static readonly string[] StaffDoors = { "OfficeDoor", "ServiceDoor" };
    // Collection signs in the procedural sign frames over the wall cases (rings left,
    // necklaces right); the rear and counter frames keep their emblem.
    public static readonly string[] RingSigns = { "Sign_Left0", "Sign_Left1", "Sign_Left2" };
    public static readonly string[] NecklaceSigns = { "Sign_Right0", "Sign_Right1" };

    // Opaque, unlit-by-emission Standard quad showing NightGraphics/<file>.png, facing the
    // parent's -z; null (nothing placed) when the image is absent.
    private static GameObject Sign(string name, string file, Transform parent, Vector3 position, Vector2 size)
    {
        Texture2D texture = DemoAssetLibrary.SignTexture(GraphicsPack, file + ".png");
        if (texture == null) return null;
        Material m = Mat(Folder, "NightSign_" + file, Color.white, 0.2f);
        m.mainTexture = texture;
        m.SetFloat("_Metallic", 0);
        m.DisableKeyword("_EMISSION");
        EditorUtility.SetDirty(m);
        GameObject quad = Primitive(name, PrimitiveType.Quad, parent, position, new Vector3(size.x, size.y, 1), m);
        quad.GetComponent<MeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        return quad;
    }

    // Staff Only on the showroom face of both closed side-room doors (on the leaf, so it
    // would swing with it), and the collection signs inside the procedural sign frames
    // (a user-converted sign_frame model keeps its own face).
    private static void InteriorSigns(Transform showroom, Transform office)
    {
        foreach (string door in StaffDoors)
        {
            Transform leaf = office.Find(door + "/Door");
            if (leaf != null) Sign(StaffSign, "StaffOnly", leaf, V(0.447f, 1.55f, -0.042f), new Vector2(0.4f, 0.2f));
        }
        if (DemoAssetLibrary.Has(StoreKit.OverridePack, "sign_frame")) return;
        foreach (string[] group in new[] { RingSigns, NecklaceSigns })
            foreach (string frame in group)
            {
                Transform t = showroom.Find(frame);
                if (t != null) Sign(CollectionSign, group == RingSigns ? "CollectionRings" : "CollectionNecklaces", t, V(0, 0.35f, -0.026f), new Vector2(0.7f, 0.35f));
            }
    }

    // Prototype/ThirdParty/NightAudio, the staged clips' fallback pack: NightAudioBuilder puts
    // them (or their NightSoundscape replacements) on a DemoSoundBank beside the tool station.
    public const string AudioPack = "NightAudio";

    // ---------------------------------------------------------------- exterior

    private static void Exterior(Transform parent, bool imported)
    {
        Transform ground = Group("Ground", parent);
        GameObject solid = Group("Colliders", ground).gameObject;
        KitMesh paving = new KitMesh { LightmapScale = NightLighting.GroundScale }, kerbs = new KitMesh { LightmapScale = NightLighting.GroundScale }, road = new KitMesh { LightmapScale = NightLighting.StreetScale }, far = new KitMesh { LightmapScale = NightLighting.FarScale };
        float hx = L.StreetHalfX, kerb = 0.18f;
        // Near pavement and kerb (the 0.12 m step down to the street), wet street, far side.
        Slab(paving, solid, StoreKit.Pavement, V(-hx, -0.3f, L.KerbZ + kerb), V(hx, 0, L.MinZ), false);
        Slab(kerbs, solid, StoreKit.Concrete, V(-hx, -0.3f, L.KerbZ), V(hx, 0, L.KerbZ + kerb), false);
        Slab(road, solid, StoreKit.Asphalt, V(-hx, L.StreetY - 0.3f, L.FarKerbZ), V(hx, L.StreetY, L.KerbZ), false);
        Slab(kerbs, solid, StoreKit.Concrete, V(-hx, -0.3f, L.FarKerbZ - kerb), V(hx, 0, L.FarKerbZ), false);
        // The far pavement runs on under the buildings across the street, ending behind their
        // backs (the apartment block's back wall is at FarPavementZ - 9); it bakes coarsely.
        Slab(far, solid, StoreKit.Pavement, V(-hx, -0.3f, L.FarPavementZ - 10), V(hx, 0, L.FarKerbZ - kerb), false);
        // Dashed centre line, 2 mm proud of the asphalt.
        float lineZ = (L.KerbZ + L.FarKerbZ) * 0.5f, y = L.StreetY + 0.002f;
        for (float x = -hx + 1; x + 2 <= hx; x += 4)
            road.Face(StoreKit.RoadLine, Vector3.up, V(x, y, lineZ - 0.06f), V(x + 2, y, lineZ - 0.06f), V(x + 2, y, lineZ + 0.06f), V(x, y, lineZ + 0.06f));
        paving.Emit("Pavement", ground, Vector3.zero, Quaternion.identity, Folder, "night_pavement");
        kerbs.Emit("Kerbs", ground, Vector3.zero, Quaternion.identity, Folder, "night_kerbs");
        road.Emit("Street", ground, Vector3.zero, Quaternion.identity, Folder, "night_street");
        far.Emit("FarPavement", ground, Vector3.zero, Quaternion.identity, Folder, "night_far_pavement");

        Transform bollards = Group("Bollards", parent);
        for (int i = 0; i < L.BollardX.Length; i++) NightStreet.Bollard(bollards, i, imported);
        Streetlights(Group("Streetlights", parent), imported);
        PoliceCar(parent, imported);
        Equipment(Group("Equipment", parent));
        Buildings(Group("Buildings", parent), imported);
        NightStreet.Apply(parent, imported);
        // Kit props share the atlas with shadows off; the car and the buildings need their
        // contact shadows on the wet street under the headlights and streetlights, and so do
        // the KayKit lamp posts. The lantern casts none (its light sits inside it). Glass
        // never casts (the Standard shader would dither it; PlacePack's rule, DemoAssetLibrary.Blended).
        List<string> shadowed = new List<string> { "PoliceCar", "Buildings" };
        if (L.Lamp.CastsShadows) shadowed.Add("Streetlights");
        foreach (string name in shadowed)
            foreach (MeshRenderer r in parent.Find(name).GetComponentsInChildren<MeshRenderer>(true))
            {
                if (DemoAssetLibrary.Blended(r))
                {
                    r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                    continue;
                }
                r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
                r.receiveShadows = true;
            }

        GameObject walls = Group("Boundary", parent).gameObject;
        for (int i = 0; i + 1 < L.BoundaryWalls.Length; i += 2)
        {
            BoxCollider c = walls.AddComponent<BoxCollider>();
            c.center = L.BoundaryWalls[i];
            c.size = L.BoundaryWalls[i + 1];
        }
    }

    // Streetlights of the layout's lamp profile (light sources and lenses are added by the
    // lighting pass at the StreetlightLight anchors): the StreetModels lantern (LOD levels,
    // no shadows, its bulb drawn as the palette's dark lens inside the lighting's emissive
    // lens box), else the KayKit streetlight; a post with the profile's head stands in
    // without either pack.
    private static void Streetlights(Transform parent, bool imported)
    {
        L.LampProfile profile = L.Lamp;
        bool lantern = profile.Model == L.Lantern.Model;
        for (int i = 0; i < L.Streetlights.Length; i++)
        {
            Transform lamp = Group("Streetlight_" + i, parent);
            lamp.localPosition = L.Streetlights[i];
            float yaw = L.StreetlightYaw(i);
            GameObject model = null;
            if (imported && lantern)
                model = DemoAssetLibrary.PlacePack(profile.Pack, profile.Model, lamp, Vector3.zero, 0, new DemoAssetLibrary.PackOptions
                {
                    Scale = profile.Scale, Shadows = false, Lod = DemoAssetLibrary.LodClass.Post,
                    Remap = material => material == "LampBulb" ? StoreKit.LightLens : null
                });
            else if (imported) model = DemoAssetLibrary.Place(profile.Pack, profile.Model, lamp, Vector3.zero, yaw, profile.Scale);
            if (model == null)
            {
                KitMesh k = new KitMesh { LightmapScale = NightLighting.KitScale };
                if (profile.Arm)
                {
                    k.Box(StoreKit.FrameMetal, V(0, 2.15f, 0), V(0.12f, 4.3f, 0.12f));
                    Quaternion turn = Quaternion.Euler(0, yaw, 0);
                    k.Box(StoreKit.FrameMetal, turn * V(-0.5f, 4.3f, 0), V(1.0f, 0.08f, 0.08f), turn);
                    k.Box(StoreKit.Lacquer, turn * V(-1.0f, 4.22f, 0), V(0.45f, 0.1f, 0.22f), turn);
                }
                else
                {
                    // Post up to the lantern's base and its cap over the light; open between.
                    float top = profile.HeadHeight - 0.2f;
                    k.Box(StoreKit.FrameMetal, V(0, top * 0.5f, 0), V(0.1f, top, 0.1f));
                    k.Box(StoreKit.FrameMetal, V(0, profile.HeadHeight + 0.21f, 0), V(0.36f, 0.06f, 0.36f));
                }
                GameObject standIn = k.Emit("StreetlightStandIn", lamp, Vector3.zero, Quaternion.identity, Folder, "night_streetlight");
                if (!profile.CastsShadows)
                {
                    MeshRenderer r = standIn.GetComponent<MeshRenderer>();
                    if (r != null) r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                }
            }
            BoxCollider post = lamp.gameObject.AddComponent<BoxCollider>();
            post.center = V(0, 1.5f, 0);
            post.size = V(0.2f, 3f, 0.2f);
        }
    }

    // The car a build placed and the anchors it used (PoliceLook.ActiveCar, or the KayKit
    // entry when that one could not be placed); NightLighting sizes the headlamp lenses and
    // the light-bar halves from it. Default (no Model) until a build in this editor session.
    public static PoliceLook.Car PlacedCar { get; private set; }

    // PoliceLook's active car: a StreetModels car through PlacePack (LOD levels, shadows,
    // turned by its ModelEuler), else today's KayKit police car (nose +z, see
    // NightStoreLayout) or ShopCityRefinement's stand-in, whose nose is +x and so is
    // turned -90 to match; one box collider round the body, anchors from the car placed.
    private static void PoliceCar(Transform parent, bool imported)
    {
        Transform car = Group("PoliceCar", parent);
        car.localPosition = L.CarPosition;
        car.localRotation = Quaternion.Euler(0, L.CarYaw, 0);
        PoliceLook.Car c = PoliceLook.ActiveCar;
        GameObject placed = imported && c.Pack == NightStreet.StreetPack
            ? DemoAssetLibrary.PlacePack(c.Pack, c.Model, car, Vector3.zero, 0, new DemoAssetLibrary.PackOptions
            {
                Scale = c.Scale, ModelEuler = c.ModelEuler, Shadows = true, Lod = DemoAssetLibrary.LodClass.Large
            })
            : null;
        if (placed == null)
        {
            c = PoliceLook.KayKitCar;
            bool kit = imported && DemoAssetLibrary.Has(c.Pack, c.Model);
            Transform model = ShopCityRefinement.Car(car, Vector3.zero, StoreKit.Lacquer, c.Model, 0, imported);
            if (!kit) model.localRotation = Quaternion.Euler(0, -90, 0);
        }
        PlacedCar = c;
        DemoAssetLibrary.AddBoundsCollider(car.gameObject);
        Group("HeadlightLeft", car).localPosition = c.HeadlightLeft;
        Group("HeadlightRight", car).localPosition = c.HeadlightRight;
        Group("LightBar", car).localPosition = c.LightBar;
    }

    // Folding table (top at TableTop) the tool samples and the camera rest on, and the
    // easel board carrying the photo frame and the status text.
    private static void Equipment(Transform parent)
    {
        Transform table = Group("FoldingTable", parent);
        table.localPosition = L.Table;
        KitMesh k = new KitMesh { LightmapScale = NightLighting.KitScale };
        float tw = L.TableWidth, td = L.TableDepth, th = L.TableTop;
        k.Box(StoreKit.PaintedGrey, V(0, th - 0.015f, 0), V(tw, 0.03f, td));
        for (int s = -1; s <= 1; s += 2)
        {
            for (int t = -1; t <= 1; t += 2)
                k.Box(StoreKit.FrameMetal, V(s * (tw * 0.5f - 0.12f), (th - 0.03f) * 0.5f, t * (td * 0.5f - 0.06f)), V(0.025f, th - 0.03f, 0.025f));
            k.Box(StoreKit.FrameMetal, V(s * (tw * 0.5f - 0.12f), 0.12f, 0), V(0.02f, 0.02f, td - 0.12f));
        }
        k.Emit("Body", table, Vector3.zero, Quaternion.identity, Folder, "night_table");
        BoxCollider top = table.gameObject.AddComponent<BoxCollider>();
        top.center = V(0, th * 0.5f, 0);
        top.size = V(tw, th, td);

        Transform easel = Group("Easel", parent);
        easel.localPosition = L.Easel;
        KitMesh e = new KitMesh { LightmapScale = NightLighting.KitScale };
        float bw = L.EaselWidth, b0 = L.EaselBottom, b1 = L.EaselTop;
        e.Box(StoreKit.DeviceBlack, V(0, (b0 + b1) * 0.5f, 0), V(bw, b1 - b0, 0.03f));
        for (int s = -1; s <= 1; s += 2)
        {
            e.Box(StoreKit.FrameMetal, V(s * (bw * 0.5f - 0.05f), b1 * 0.5f, 0.035f), V(0.04f, b1, 0.04f));
            e.Box(StoreKit.FrameMetal, V(s * (bw * 0.5f - 0.05f), 0.02f, 0.035f), V(0.05f, 0.04f, 0.6f));
        }
        e.Emit("Body", easel, Vector3.zero, Quaternion.identity, Folder, "night_easel");
        BoxCollider board = easel.gameObject.AddComponent<BoxCollider>();
        board.center = V(0, b1 * 0.5f, 0.02f);
        board.size = V(bw, b1, 0.1f);
    }

    // Terrace neighbours either side of the shop (brick left, render right) and a row across
    // the street of render-and-glass blocks with a few lit rooms (baked emitters), with
    // StreetModels' apartment block directly opposite when the pack is present
    // (NightStreet.AcrossLayout keeps its slot free). The terrace bakes at the street's
    // density; the row across the street is lightmapped at the far density, so the far
    // streetlights' pools reach its shopfronts. Two renderers, not one huge bounds.
    private static void Buildings(Transform parent, bool imported)
    {
        System.Random rng = new System.Random(5);
        KitMesh near = new KitMesh { LightmapScale = NightLighting.StreetScale }, across = new KitMesh { LightmapScale = NightLighting.FarScale };
        GameObject solid = Group("Colliders", parent).gameObject;
        foreach (float s in new[] { -1f, 1f })
        {
            float x0 = s < 0 ? -20 : L.MaxX + L.Pier, x1 = s < 0 ? L.MinX - L.Pier : 20;
            Slab(near, solid, s < 0 ? StoreKit.Brick : StoreKit.Render, V(x0, 0, L.MinZ), V(x1, 7.5f, 14), false);
            Shopfront(near, x0, x1, L.MinZ, -1);
            Windows(near, rng, x0, x1, L.MinZ, -1, 7.5f, 0.25f);
        }
        bool apartment = NightStreet.HasApartment(imported);
        NightStreet.Across a = NightStreet.AcrossLayout(apartment);
        for (int i = 0; i < a.Heights.Length; i++)
        {
            float x0 = a.Edges[2 * i], x1 = a.Edges[2 * i + 1];
            across.Box(StoreKit.Render, V((x0 + x1) * 0.5f, a.Heights[i] * 0.5f, L.FarPavementZ - 5), V(x1 - x0, a.Heights[i], 10), false);
            // The blank slot keeps a plain ground floor for the street posters.
            if (i != a.Blank) Shopfront(across, x0, x1, L.FarPavementZ, 1);
            Windows(across, rng, x0, x1, L.FarPavementZ, 1, a.Heights[i], 0.2f);
        }
        near.Emit("Neighbours", parent, Vector3.zero, Quaternion.identity, Folder, "night_neighbours");
        across.Emit("AcrossStreet", parent, Vector3.zero, Quaternion.identity, Folder, "night_across");
        if (!apartment) return;
        // ApartmentBlock (CC0): OBJ x -0.355..15.355 mirrors on import, so this root puts the
        // block on x0..x0 + 15.71; its facade at file z 0 faces +z, the street, on the far
        // pavement's front line. It has a second UV set (ThirdPartyModelImport pads its charts
        // for the street density), so MarkStatic lightmaps it (NightLighting gives it
        // StreetScale) and makes it an occluder like the boxes.
        DemoAssetLibrary.PlacePack(NightStreet.StreetPack, NightStreet.Apartment, parent,
            V(a.ApartmentX0 + NightStreet.ApartmentPivotX, 0, L.FarPavementZ), 0, new DemoAssetLibrary.PackOptions { Shadows = true });
    }

    // Ground-floor shop: dark glass band, a half-closed roller shutter and a fascia board.
    // facing is the facade normal's z (-1 towards the near street side, +1 across).
    private static void Shopfront(KitMesh k, float x0, float x1, float z, float facing)
    {
        float f = z + facing * 0.01f, mid = (x0 + x1) * 0.5f;
        Vector3 n = V(0, 0, facing);
        k.Face(StoreKit.WindowDark, n, V(x0 + 0.6f, 0.3f, f), V(x1 - 0.6f, 0.3f, f), V(x1 - 0.6f, 2.8f, f), V(x0 + 0.6f, 2.8f, f));
        f += facing * 0.005f;
        k.Face(StoreKit.Shutter, n, V(mid, 0.3f, f), V(x1 - 0.6f, 0.3f, f), V(x1 - 0.6f, 2.8f, f), V(mid, 2.8f, f));
        k.Box(StoreKit.FrameMetal, V(mid, 3.2f, z + facing * 0.06f), V(x1 - x0 - 0.8f, 0.6f, 0.12f));
    }

    // Upper-floor window grid on a facade, about litChance of the rooms lit.
    private static void Windows(KitMesh k, System.Random rng, float x0, float x1, float z, float facing, float height, float litChance)
    {
        float f = z + facing * 0.01f;
        for (float y = 4.2f; y + 1.5f <= height - 0.8f; y += 3.0f)
            for (float x = x0 + 1.0f; x + 1.2f <= x1 - 0.8f; x += 2.4f)
            {
                Material m = rng.NextDouble() < litChance ? StoreKit.WindowLit : StoreKit.WindowDark;
                k.Face(m, V(0, 0, facing), V(x, y, f), V(x + 1.2f, y, f), V(x + 1.2f, y + 1.5f, f), V(x, y + 1.5f, f));
            }
    }

    // ---------------------------------------------------------------- fixtures

    // A layout fixture: case, safe and door states come from the dressing's case state, the
    // camera's aim from NightStoreLayout.CameraAim (always the procedural camera), everything
    // else through StoreKit.Instantiate (user-converted model when present).
    private static void Place(L.Fixture f, Transform parent)
    {
        GameObject g;
        switch (f.Kit)
        {
            case "display_case":
                g = StoreKit.DisplayCase(parent, NightStoreDressing.CaseGlass(f.Name), NightStoreDressing.HasDrawer(f.Name), NightStoreDressing.DrawerOut(f.Name));
                break;
            case "wall_case": g = StoreKit.WallCase(parent, NightStoreDressing.CaseGlass(f.Name)); break;
            case "safe_large": g = StoreKit.SafeLarge(parent, NightStoreDressing.SafeOpen(f.Name)); break;
            case "safe_tall": g = StoreKit.SafeTall(parent, NightStoreDressing.SafeOpen(f.Name)); break;
            case "office_door": g = StoreKit.OfficeDoor(parent, 0); break;
            case "service_door": g = StoreKit.ServiceDoor(parent, 0); break;
            // Square to the partition; only its arm and housing turn towards the entrance.
            case "security_camera": g = StoreKit.SecurityCamera(parent, L.CameraAim); break;
            default: g = StoreKit.Instantiate(f.Kit, parent, f.Position, f.Yaw); break;
        }
        g.name = f.Name;
        g.transform.localPosition = f.Position;
        g.transform.localRotation = Quaternion.Euler(0, f.Yaw, 0);
    }
}
#endif
