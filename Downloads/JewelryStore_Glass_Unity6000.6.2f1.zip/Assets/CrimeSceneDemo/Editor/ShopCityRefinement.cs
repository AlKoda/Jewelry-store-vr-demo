#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using static DemoGeometry;

public static class ShopCityRefinement
{
    private const string Folder="Assets/CrimeSceneDemo/CityGenerated";
    private const string Pack="KenneyCityBuilder";
    // KayKit City Kit (CC0): low-poly props and buildings sharing one atlas texture.
    public const string KitPack="KayKitCity";
    public const float KitScale=4.5f;
    private static Material stone, dark, metal, cream, road, glass, green, brick, white, glow;
    private static Transform city;
    private static bool importedAssets;

    [MenuItem("Crime Scene Demo/Refine Shop And Add Street")]
    public static void Apply() { Apply(true); }

    public static void Apply(bool useImportedAssets)
    {
        importedAssets=useImportedAssets;
        GameObject store=GameObject.Find("JewelryStore_Blockout");
        if(store==null) throw new System.InvalidOperationException("Generate the store first.");
        if(GameObject.Find("CityBackdrop")!=null)
            throw new System.InvalidOperationException("City already exists. Generate into a fresh scene.");
        EnsureFolder(Folder);
        Materials();
        Transform tools=store.transform.Find("ToolSystem");
        foreach(Renderer r in store.GetComponentsInChildren<Renderer>())
        {
            if(tools!=null && r.transform.IsChildOf(tools)) continue;
            string n=r.name.ToLowerInvariant();
            Material m=cream;
            if(n.Contains("floor")) m=stone;
            if(n=="base" || n.Contains("counter") || n.Contains("safe") || n=="door" ||
                n=="back" || n=="left" || n=="right" || n.Contains("toolrack")) m=dark;
            if(n.Contains("rail") || n.Contains("post") || n.Contains("trim") ||
                n.Contains("wheel") || n.Contains("dial") || n.Contains("segment")) m=metal;
            if(n.Contains("shard") || n.Contains("glass")) m=glass;
            if(n.Contains("tread") || n.Contains("heel")) m=dark;
            if(r is MeshRenderer && r.GetComponent<TextMesh>()==null) r.sharedMaterial=m;
        }
        Transform oldPavement=store.transform.Find("Architecture/Pavement");
        if(oldPavement!=null) Object.DestroyImmediate(oldPavement.gameObject);
        Transform detail=Group("ShopDetails",store.transform);
        // Thin geometric joints provide scale without texture maps.
        for(int x=-4;x<5;x++)
            Box("FloorJoint",detail,V(x,.002f,4),V(.008f,.002f,8),dark);
        for(int z=1;z<8;z++)
            Box("FloorJoint",detail,V(0,.002f,z),V(10,.002f,.008f),dark);
        Box("BackFeaturePanel",detail,V(-1.5f,1.8f,7.98f),V(4.4f,1.6f,.035f),dark);
        Text("Brand",detail,"ATELIER",V(-1.5f,2.12f,7.95f),0,.11f,cream.color);
        Text("BrandSubtitle",detail,"F I N E   J E W E L L E R Y",V(-1.5f,1.58f,7.94f),0,.036f,cream.color);
        for(int i=0;i<3;i++)
        {
            Box("CeilingTrack",detail,V(-3+i*3,2.92f,4),V(.07f,.08f,6),dark);
            for(int j=0;j<3;j++)
                Box("CeilingLight",detail,V(-3+i*3,2.84f,1.8f+j*2),V(.26f,.08f,.32f),glow);
        }
        for(int side=-1;side<=1;side+=2)
        {
            Box("Skirting",detail,V(side*4.98f,.10f,4),V(.025f,.2f,8),dark);
            Box("WallCornice",detail,V(side*4.96f,2.65f,4),V(.06f,.08f,8),metal);
        }
        // Collider spans ALL glazing and entrance; backdrop is view-only.
        GameObject barrier=new GameObject("IndoorBoundary_Front");
        barrier.transform.SetParent(store.transform,false);
        barrier.transform.localPosition=V(0,1.5f,-.05f);
        barrier.AddComponent<BoxCollider>().size=V(10.4f,3,.15f);

        city=Group("CityBackdrop",null);
        Box("DistantGround",city,V(0,-.22f,-22),V(180,.2f,160),stone);
        Box("Street",city,V(0,-.09f,-7),V(140,.1f,8),road);
        // Sidewalks get their own (identical-looking) material so a texture pass can tile them alone.
        Material pavement=Mat("Pavement",stone.color);
        Box("NearSidewalk",city,V(0,-.10f,-1.5f),V(140,.2f,3),pavement);
        Box("FarSidewalk",city,V(0,-.1f,-13),V(140,.2f,4),pavement);
        Box("NearKerb",city,V(0,-.015f,-3),V(140,.15f,.16f),cream);
        Box("FarKerb",city,V(0,-.015f,-11),V(140,.15f,.16f),cream);
        for(int i=-16;i<=16;i++)
            Box("LaneDash",city,V(i*4,-.033f,-7),V(1.8f,.005f,.10f),white);
        for(int i=0;i<7;i++)
            Box("Crosswalk",city,V(12,-.03f,-10.3f+i),V(2.4f,.006f,.42f),white);
        string[] signs={"BOOKS","CAFE","STUDIO","BAKERY","FLORIST","DESIGN","MARKET"};
        for(int i=-3;i<=3;i++)
            Building("Across_"+i,V(i*9,0,-19),8,9+(i+3)%3*2,8,
                i%2==0?stone:brick,signs[i+3],0);
        // Side buildings form the continuation of the shop's street frontage.
        Building("Neighbor_Left",V(-12,0,2.7f),12,9,9,brick,"GALLERY",180);
        Building("Neighbor_Right",V(12,0,2.7f),12,12,9,stone,"PHARMACY",180);
        string[] blocks={"building-small-a","building-small-b","building-small-c","building-small-d","building-garage"};
        string[] towers={"building_H_withoutBase","building_C_withoutBase","building_D_withoutBase","building_F_withoutBase"};
        for(int i=-4;i<=4;i++)
        {
            // Odd slots take KayKit towers (bases removed, so they sink 0.1 units), even slots
            // Kenney CC0 buildings (1 m tiles scaled up); boxes stand in for missing packs.
            GameObject block=i%2!=0?Kit(towers[(i+3)/2],city,V(i*13,-.7f,-40),0,7):null;
            if(block==null) block=PlaceCityAsset(blocks[(i+4)%blocks.Length],city,V(i*13,0,-40),(i%2==0)?0:180,12);
            if(block==null) Box("DistantBlock",city,V(i*13,10+(i+4)%3*2,-40),V(10,20+(i+4)%3*4,12),stone);
            if(i%2==0) Lamp(V(i*8,0,-11.8f));
        }
        if(PlaceCityAsset("pavement-fountain",city,V(2,-.02f,-13),0,4)!=null)
            Box("FountainPlinth",city,V(2,-.015f,-13),V(4.2f,.03f,4.2f),cream);
        Car(V(-7,-.02f,-9.4f),dark,"car_sedan",90);
        Car(V(10,-.02f,-4.5f),brick,"car_taxi",-90);
        // A patrol car at the kerb in front of the window tells the story from inside the shop.
        Car(V(-1.5f,-.02f,-4.6f),white,"car_police",-90);
        Car(V(-16,-.02f,-9.4f),stone,"car_hatchback",90);
        Car(V(19,-.02f,-9.6f),glass,"car_stationwagon",90);
        Bench(V(-3,0,-12.3f));
        Bench(V(8,0,-12.3f));
        for(int i=0;i<3;i++)
            if(PlaceCityAsset("grass-trees-tall",city,V(-13+i*13,0,-13.2f),i*90,3.5f)==null)
                Planter(V(-13+i*13,0,-13.2f));
        StreetFurniture();
        // Consolidate static backdrop by material into persistent mesh assets.
        CombineByMaterial(city,Folder+"/CityMesh_","City_");
        RenderSettings.fog=true;
        RenderSettings.fogMode=FogMode.Linear;
        RenderSettings.fogColor=new Color(.65f,.72f,.75f);
        RenderSettings.fogStartDistance=35;
        RenderSettings.fogEndDistance=110;
        AssetDatabase.SaveAssets();
    }

    private static void Materials()
    {
        stone=Mat("WarmStone",new Color(.64f,.61f,.54f));
        cream=Mat("Ivory",new Color(.84f,.81f,.72f));
        dark=Mat("CharcoalWood",new Color(.16f,.19f,.19f));
        metal=Mat("BrushedBrass",new Color(.48f,.36f,.19f));
        road=Mat("Asphalt",new Color(.18f,.20f,.22f));
        glass=Mat("OpaqueWindow",new Color(.19f,.30f,.35f));
        green=Mat("Foliage",new Color(.21f,.30f,.23f));
        brick=Mat("Terracotta",new Color(.48f,.29f,.22f));
        white=Mat("RoadMarking",new Color(.83f,.84f,.80f));
        glow=Glowing(Mat("LampGlow",new Color(.95f,.92f,.82f)),new Color(1f,.93f,.75f)*1.4f);
    }

    private static void Building(string name,Vector3 p,float width,float height,float depth,
        Material wall,string sign,float facing)
    {
        Transform g=Group(name,city);
        g.localPosition=p; g.localRotation=Quaternion.Euler(0,facing,0);
        Box("Shell",g,V(0,height/2,0),V(width,height,depth),wall);
        float face=depth/2+.04f;
        Box("Plinth",g,V(0,.4f,face),V(width,.8f,.1f),dark);
        Box("Cornice",g,V(0,height-.3f,face),V(width+.25f,.3f,.25f),cream);
        for(int row=0;row<3;row++)
        for(int col=0;col<3;col++)
        {
            float y=4.5f+row*2.7f;
            if(y+1>height) continue;
            float x=(col-1)*width*.28f;
            Box("WindowFrame",g,V(x,y,face+.04f),V(1.55f,1.8f,.1f),cream);
            Box("Window",g,V(x,y,face+.1f),V(1.33f,1.58f,.03f),glass);
            Box("Mullion",g,V(x,y,face+.13f),V(.04f,1.6f,.03f),dark);
        }
        Box("Shopfront",g,V(0,1.4f,face+.05f),V(width-.8f,2.1f,.12f),glass);
        for(int i=-1;i<=1;i++)
            Box("ShopfrontPillar",g,V(i*width*.29f,1.4f,face+.13f),V(.14f,2.3f,.12f),dark);
        Box("Signboard",g,V(0,2.95f,face+.10f),V(width-.4f,.72f,.18f),dark);
        Text("ShopSign",g,sign,V(0,2.98f,face+.21f),180,.09f,cream.color);
        Box("Awning",g,V(0,2.56f,face+.48f),V(width-.3f,.08f,1),wall);
    }

    private static void Car(Vector3 p,Material paint,string model,float yaw) { Car(city,p,paint,model,yaw); }

    // A parked car ("ParkedCar" under parent at p): the KayKit model and its four wheels
    // when the pack is present and imported assets are on, else the procedural stand-in.
    // KayKit cars are modelled lengthwise along z, nose towards +z (the hood is the
    // longer, lower end and the cabin sits towards the rear), turned by yaw; the
    // stand-in lies along x with its nose at +x and ignores yaw, as it always has.
    public static Transform Car(Transform parent,Vector3 p,Material paint,string model,float yaw,bool useImportedAssets)
    {
        importedAssets=useImportedAssets;
        if(dark==null || glass==null || cream==null)
        {
            EnsureFolder("Assets/CrimeSceneDemo");
            EnsureFolder(Folder);
            Materials();
        }
        return Car(parent,p,paint,model,yaw);
    }

    private static Transform Car(Transform parent,Vector3 p,Material paint,string model,float yaw)
    {
        Transform g=Group("ParkedCar",parent); g.localPosition=p;
        // KayKit cars are modelled lengthwise along z with the wheel bottoms 0.06 units below the origin.
        if(Kit(model,g,V(0,.06f*KitScale,0),yaw,KitScale)!=null)
        {
            foreach(string corner in new[]{"front_left","front_right","rear_left","rear_right"})
                Kit(model+"_wheel_"+corner,g,V(0,.06f*KitScale,0),yaw,KitScale);
            return g;
        }
        Mesh body=ShopFormRefinement.Loft("CarBody",new float[]{-.5f,-.35f,.3f,.5f},new float[]{.91f,1,1,.86f},new float[]{.88f,1,1,.90f},.12f);
        Mesh cabin=ShopFormRefinement.Loft("CarCabin",new float[]{-.5f,.5f},new float[]{1,.72f},new float[]{1,.85f},.08f);
        Mesh wheel=ShopFormRefinement.Loft("CarWheel",new float[]{-.5f,.5f},new float[]{1,1},new float[]{1,1},.146447f);
        ShopFormRefinement.Shape("Body",g,body,V(0,.55f,0),V(4,.65f,1.65f),paint);
        ShopFormRefinement.Shape("Cabin",g,cabin,V(0,1.08f,0),V(2.1f,.55f,1.45f),glass);
        for(int x=-1;x<=1;x+=2)
        for(int z=-1;z<=1;z+=2)
            ShopFormRefinement.Shape("Wheel",g,wheel,V(x*1.3f,.32f,z*.77f),V(.62f,.25f,.62f),dark)
                .transform.localRotation=Quaternion.Euler(90,0,0);
        Box("FrontLamp",g,V(2.02f,.65f,0),V(.03f,.17f,1.3f),cream);
        return g;
    }
    private static void Lamp(Vector3 p)
    {
        Transform g=Group("StreetLamp",city); g.localPosition=p;
        // The KayKit light arm points along -x; yaw 90 swings it over the street.
        if(Kit("streetlight",g,Vector3.zero,90,KitScale)!=null) return;
        if(importedAssets && DemoAssetLibrary.Place("KhronosSamples","Lantern",g,Vector3.zero,0,1)!=null) return;
        Box("Post",g,V(0,2.2f,0),V(.09f,4.4f,.09f),dark);
        Box("Arm",g,V(0,4.35f,.45f),V(.09f,.09f,.9f),dark);
        Box("Head",g,V(0,4.28f,.9f),V(.3f,.10f,.5f),glow);
    }
    private static void Bench(Vector3 p)
    {
        Transform g=Group("Bench",city);g.localPosition=p;
        if(Kit("bench",g,Vector3.zero,0,KitScale)!=null) return;
        Box("Seat",g,V(0,.48f,0),V(1.8f,.10f,.45f),dark);
        Box("Back",g,V(0,.78f,-.2f),V(1.8f,.5f,.08f),dark);
        for(int x=-1;x<=1;x+=2) Box("Leg",g,V(x*.65f,.24f,0),V(.08f,.48f,.4f),metal);
    }
    private static void Planter(Vector3 p)
    {
        Transform g=Group("Planter",city);g.localPosition=p;
        Box("Pot",g,V(0,.35f,0),V(.9f,.7f,.9f),dark);
        Box("Trunk",g,V(0,1.35f,0),V(.13f,2,.13f),metal);
        for(int i=0;i<3;i++)
        {
            GameObject crown=Box("Canopy",g,V(0,2.5f+i*.35f,0),
                V(1.6f-i*.3f,.65f,1.5f-i*.25f),green);
            crown.transform.localRotation=Quaternion.Euler(0,i*30,0);
        }
    }

    // Kerbside detail that only exists with the KayKit pack: hydrant by the shop, traffic
    // lights at both ends of the crossing, a dumpster in the gap between the far buildings,
    // bushes along the far pavement. Nothing stands in for them when the pack is absent.
    private static void StreetFurniture()
    {
        if(!importedAssets || !DemoAssetLibrary.Has(KitPack,"firehydrant")) return;
        Transform g=Group("StreetFurniture",city);
        Kit("firehydrant",g,V(-5.5f,0,-2.6f),0,KitScale);
        Kit("trafficlight_A",g,V(14,0,-2.7f),180,KitScale);
        Kit("trafficlight_A",g,V(10,0,-11.3f),0,KitScale);
        Kit("dumpster",g,V(-13.5f,0,-13.8f),0,KitScale);
        Kit("trash_A",g,V(-12.4f,0,-12.9f),40,KitScale);
        Kit("box_A",g,V(-14.9f,0,-13.1f),15,KitScale);
        Kit("box_B",g,V(-14.6f,0,-14.2f),70,KitScale);
        for(int i=-1;i<=2;i++) Kit("bush",g,V(-24+i*16,0,-14.3f),i*70,3);
    }

    private static GameObject PlaceCityAsset(string model,Transform parent,Vector3 p,float yaw,float scale)
        => importedAssets?DemoAssetLibrary.Place(Pack,model,parent,p,yaw,scale):null;
    private static GameObject Kit(string model,Transform parent,Vector3 p,float yaw,float scale)
        => importedAssets?DemoAssetLibrary.Place(KitPack,model,parent,p,yaw,scale):null;

    private static Material Mat(string name,Color color) => DemoGeometry.Mat(Folder,name,color,.12f);
}
#endif
